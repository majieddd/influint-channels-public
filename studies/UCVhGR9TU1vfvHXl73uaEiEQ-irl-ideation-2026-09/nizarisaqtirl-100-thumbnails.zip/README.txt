Nizarisaqt IRL: 100 reference-composition concepts, revision 2026-09-24.
1280x720 JPEGs plus generation prompts and SHA-256 manifest.
Built-in image generation; model identity not exposed. GPT Image 2.5 Flare is not certified.
Supporting cast may be illustrative. Replace concept scenes with shoot-specific references before final packaging.
These are proposed episodes, not evidence that the pictured events occurred.
